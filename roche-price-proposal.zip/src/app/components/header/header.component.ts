import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() getUser: any;
  username:any = '';

  constructor() { }

  ngOnInit(): void {
    this.username = localStorage.getItem("rochePP");
    console.log("USER>.", this.getUser)
  }
  logout(){
    console.log('Logout')
  }
}

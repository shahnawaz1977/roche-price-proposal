import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-proposal',
  templateUrl: './price-proposal.component.html',
  styleUrls: ['./price-proposal.component.css']
})
export class PriceProposalComponent implements OnInit {
  isUser = true;
  step = 1;
  constructor() { }

  ngOnInit(): void {
  }
  checkSteps(){
    this.step = this.step+1;
  }
  clickStep(val: any){
    this.step = val;
  }
}

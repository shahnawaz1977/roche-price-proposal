import {Component, OnInit} from '@angular/core';
import { USERS } from './users';


@Component({
  selector: 'app-initiator',
  templateUrl: './initiator.component.html',
  styleUrls: ['./initiator.component.css']
})
export class InitiatorComponent implements OnInit {
  isUser = true;
  page = 1;
  pageSize = 10;
  collectionSize = USERS.length;
  UserList = USERS;
  searchKey = '';
  isLoading = false;

  constructor() {
    //this.refreshCountries();
  }

  ngOnInit(): void {
    this.UserList = USERS;
  }
  
  refreshCountries() {
    //
  }
  search(){
    this.isLoading = true;
    if(this.searchKey == ''){
      this.isLoading = false;
      this.ngOnInit();
    }else{
      this.UserList = USERS;
      
      this.UserList = this.UserList.filter(res =>{
        this.isLoading = false;
        return res.email.toLocaleLowerCase().match(this.searchKey.toLocaleLowerCase())
      })
    }
  }
}

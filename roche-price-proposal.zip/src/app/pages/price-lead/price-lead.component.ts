import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-lead',
  templateUrl: './price-lead.component.html',
  styleUrls: ['./price-lead.component.css']
})
export class PriceLeadComponent implements OnInit {
  isUser = true;
  constructor() { }

  ngOnInit(): void {
  }

}
